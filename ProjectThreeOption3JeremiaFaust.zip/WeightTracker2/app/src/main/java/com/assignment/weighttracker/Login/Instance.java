package com.assignment.weighttracker.Login;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
//this class sets ups instance so user can login.
public class Instance {

    private final SharedPreferences prefs;

    public Instance(Context context) {
        prefs = PreferenceManager.getDefaultSharedPreferences(context);
    }

    public void setId(String id) {
        prefs.edit().putString("id", id).apply();
    }

    public String getId() {
        return prefs.getString("id","");
    }
}

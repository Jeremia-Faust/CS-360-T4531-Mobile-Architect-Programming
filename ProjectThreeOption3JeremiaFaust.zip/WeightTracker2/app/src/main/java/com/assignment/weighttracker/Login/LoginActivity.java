package com.assignment.weighttracker.Login;


import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.assignment.weighttracker.R;
import com.assignment.weighttracker.WeightDatabase;

//sets up login screen
public class LoginActivity extends AppCompatActivity {
    WeightDatabase wdb;
    EditText UserName;
    EditText UserPassword;
    Button loginBtn;
    Button addUserBtn;
    Instance instance;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        wdb = new WeightDatabase(this);
        instance = new Instance(this);

        UserName = findViewById(R.id.UserName);
        UserPassword = findViewById(R.id.UserPassword);
        loginBtn = findViewById(R.id.loginBtn);
        addUserBtn = findViewById(R.id.addUserBtn);
        loginBtn.setOnClickListener(this::loginUser);
        addUserBtn.setOnClickListener(view -> register());

    }
    //login method know
    // TO DO fix after first login it auto logs in have to uninstall to login again
    void loginUser(View view) {
        String name = UserName.getText().toString();
        String password = UserPassword.getText().toString();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
        } else {

            userModel userModel = wdb.readUserInfo(name, password);
            String id = String.valueOf(wdb.readUserInfo(name, password));
            if (userModel != null) {

                instance.setId(id);
                Intent intent = new Intent(LoginActivity.this, Permissions.class);
                startActivity(intent);


            } else {
                Toast.makeText(this, "Invalid input please try again", Toast.LENGTH_SHORT).show();
            }
            UserName.setText("");
            UserPassword.setText("");
        }
    }

    private void register() {
        String uName = UserName.getText().toString();
        String uPassword = UserPassword.getText().toString();

        if (TextUtils.isEmpty(uName) || TextUtils.isEmpty(uPassword))
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
        else {
            int id = wdb.addUser(uName, uPassword);

            if (id < 0) {


                return;
            }
            instance.setId(String.valueOf(id));
            Toast.makeText(this, "Added user " + id + " successfully", Toast.LENGTH_LONG).show();

        }
    }
}

package com.assignment.weighttracker.Login;
//sets up user data
public class userModel {
    private int id;
    private String uName;

    private String uPassword;
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return uName;
    }
    public void setName(String uName) {
        this.uName = uName;
    }

    public String getPassword() {
        return uPassword;
    }
    public void setPassword(String uPassword) {
        this.uPassword = uPassword;
    }
}

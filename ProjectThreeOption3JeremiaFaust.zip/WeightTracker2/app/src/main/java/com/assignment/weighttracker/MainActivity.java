package com.assignment.weighttracker;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import android.content.Intent;

import android.database.Cursor;

import android.os.Bundle;
import android.view.View;

import android.widget.ImageButton;
import android.widget.Toast;

import com.assignment.weighttracker.Login.Instance;
import com.assignment.weighttracker.Login.LoginActivity;
import com.assignment.weighttracker.dailyweight.AddActivity;
import com.assignment.weighttracker.dailyweight.WeightAdaptor;
import com.assignment.weighttracker.goal.AddGoalActivity;
import com.assignment.weighttracker.goal.GoalAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    RecyclerView recyclerView2;
    FloatingActionButton addButton;
    WeightAdaptor weightAdaptor;
    GoalAdapter goalAdapter;
    ImageButton addGoalWeightBtn;
    WeightDatabase wdb;
    ArrayList<String> weight_id, weight_date, weight_weight, goal_id, goal_Weight;
    Instance instance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_page);

        instance = new Instance(this);
        if(instance.getId().equals("")){
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
        }

        addGoalWeightBtn = findViewById(R.id.addGoalWeightBtn);
        addGoalWeightBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddGoalActivity.class);
                startActivity(intent);
            }
        });
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView2 = findViewById(R.id.recyclerView2);
        addButton = findViewById(R.id.addButton);
        addButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, AddActivity.class);
            startActivity(intent);
        });
        wdb = new WeightDatabase(MainActivity.this);
        weight_id = new ArrayList<>();
        weight_date = new ArrayList<>();
        weight_weight = new ArrayList<>();

        goal_id= new ArrayList<>();
        goal_Weight = new ArrayList<>();


        displayWeightData();
        displayGoalData ();

        weightAdaptor = new WeightAdaptor(MainActivity.this, this, weight_id, weight_date, weight_weight);
        recyclerView.setAdapter(weightAdaptor);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));

        goalAdapter = new GoalAdapter(MainActivity.this,this,goal_id,goal_Weight);
        recyclerView2.setAdapter(goalAdapter);
        recyclerView2.setLayoutManager(new LinearLayoutManager(MainActivity.this));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            recreate();
        }
    }

    void displayWeightData() {
        Cursor cursor = wdb.readWeightData();
        if (cursor.getCount() == 0) {
            Toast.makeText(this, "No Data", Toast.LENGTH_SHORT).show();
        } else {
            while (cursor.moveToNext()) {
                weight_id.add(cursor.getString(0));
                weight_date.add(cursor.getString(1));
                weight_weight.add(cursor.getString(2));
            }
        }

    }
    void displayGoalData () {
        Cursor cursor = wdb.readGoalData();
        if (cursor.getCount() == 0) {
            Toast.makeText(this, "No Data", Toast.LENGTH_SHORT).show();
        } else {
            while (cursor.moveToNext()) {
                goal_id.add(cursor.getString(0));
                goal_Weight.add(cursor.getString(1));

            }
        }
    }

}


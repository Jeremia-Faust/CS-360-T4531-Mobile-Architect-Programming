package com.assignment.weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import com.assignment.weighttracker.Login.userModel;

public class WeightDatabase extends SQLiteOpenHelper {
    //Database setup
    private static final String DB_NAME = "Weight_Date.DB";
    private static final int DB_VERSION = 1;
    private final Context context;

    //Set up tables for all three tables
    private static final class LoginTable {
        private static final String USERS_TABLE_NAME = "Users";
        private static final String ID = "id";
        private static final String USER_NAME = "username";
        private static final String PASSWORD = "password";
    }

    private static final class UserDataTable {
        private static final String Weight_by_date = "UserData";
        private static final String Entry_ID = "id";
        private static final String User_Date = "date";
        private static final String User_Weight = "weight";
    }

    private static final class GoalTable {
        private static final String User_Goal = "UserGoal";
        private static final String GoalId = "id";
        private static final String Goal_Weight = "weight";
    }

    public WeightDatabase(Context context) {

        super(context, DB_NAME, null, DB_VERSION);
        this.context = context;
    }
    //sets up database layout
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + LoginTable.USERS_TABLE_NAME + " (" +
                LoginTable.ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                LoginTable.USER_NAME + " TEXT, " +
                LoginTable.PASSWORD + " TEXT);");

        db.execSQL("create table " + UserDataTable.Weight_by_date + " (" +
                UserDataTable.Entry_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                UserDataTable.User_Date + " DATE, " +
                UserDataTable.User_Weight + " DOUBLE);");

        db.execSQL("create table " + GoalTable.User_Goal + " (" +
                GoalTable.GoalId + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                GoalTable.Goal_Weight + " DOUBLE);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + LoginTable.USERS_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + UserDataTable.Weight_by_date);
        db.execSQL("DROP TABLE IF EXISTS " + GoalTable.User_Goal);
        onCreate(db);

    }
//crud methods
    public void addNewEntry(String date, Double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(UserDataTable.User_Date, date);
        values.put(UserDataTable.User_Weight, weight);

        long result = db.insert(UserDataTable.Weight_by_date, null, values);
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }


    }

    Cursor readWeightData() {
        String query = "SELECT * FROM " + UserDataTable.Weight_by_date;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, null);
        }
        return cursor;
    }

    public void updateWeightData(String id, String date, String weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(UserDataTable.User_Date, date);
        values.put(UserDataTable.User_Weight, weight);

        long result = db.update(UserDataTable.Weight_by_date, values, "id = ? ", new String[]{id});
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }

    }

    public void deleteWeightEntry(String row_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(UserDataTable.Weight_by_date, "id=?", new String[]{row_id});

        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }

    }

    public void addNewGoalEntry( Double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();


        values.put(GoalTable.Goal_Weight, weight);

        long result = db.insert(GoalTable.User_Goal, null, values);
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }


    }
    Cursor readGoalData() {
        String query = "SELECT * FROM " + GoalTable.User_Goal;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, null);
        }
        return cursor;
    }

    public void updateGoalData(String row_id, String goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(GoalTable.Goal_Weight, goalWeight);


        long result = db.update(GoalTable.User_Goal, values, "id=?", new String[]{row_id});
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }

    }
    //Sets up login
    public int addUser(String userName, String password) {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();

        ContentValues values = new ContentValues();

        values.put(LoginTable.USER_NAME, userName);
        values.put(LoginTable.PASSWORD, password);

        sqLiteDatabase.insert(LoginTable.USERS_TABLE_NAME, null, values);

        return -1;
    }



    public userModel readUserInfo(String userName, String password) {
        userModel userModel =new userModel();

        String queryString = "SELECT * FROM " + LoginTable.USERS_TABLE_NAME + " WHERE " +
                LoginTable.USER_NAME + " LIKE '" + userName + "' AND " + LoginTable.PASSWORD + " LIKE '" + password + "'";
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString, null);

        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
            userModel.setName(cursor.getString(1));
            userModel.setPassword(cursor.getString(2));
        }
        else{
            userModel = null;
        }
        cursor.close();
        return userModel;
    }






}
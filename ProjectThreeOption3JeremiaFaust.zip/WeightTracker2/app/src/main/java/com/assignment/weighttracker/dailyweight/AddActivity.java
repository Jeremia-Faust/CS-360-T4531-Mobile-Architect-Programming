package com.assignment.weighttracker.dailyweight;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.assignment.weighttracker.R;
import com.assignment.weighttracker.WeightDatabase;
//this cLass is to add to the weight data. This extends the crud from database.
public class AddActivity extends AppCompatActivity {

    EditText currentDate;
    EditText currentWeight;
    Button saveBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        currentDate = findViewById(R.id.currentDate);
        currentWeight = findViewById(R.id.currentWeight);
        saveBtn = findViewById(R.id.saveBtn);
        saveBtn.setOnClickListener(view -> {
            //on click add entry
            WeightDatabase wdb = new WeightDatabase(AddActivity.this);
            wdb.addNewEntry(currentDate.getText().toString().trim(),
                    Double.valueOf(currentWeight.getText().toString().trim()));
        });
    }
}
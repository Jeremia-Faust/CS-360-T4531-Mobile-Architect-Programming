package com.assignment.weighttracker.dailyweight;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;



import android.os.Bundle;

import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.assignment.weighttracker.R;
import com.assignment.weighttracker.WeightDatabase;

// This class sets up the update and delete functionality.
// TO DO Update functionality not working.
public class UpdateActivity extends AppCompatActivity {

    EditText updateDate;
    EditText updateWeight;
    Button updateBtn, deleteBtn;

    String id,date,weight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        updateDate = findViewById(R.id.updateDate);
        updateWeight = findViewById(R.id.updateWeight);
        updateBtn = findViewById(R.id.updateBtn);
        deleteBtn = findViewById(R.id.deleteBtn);


        getAndSetWeightIntentData();

        updateBtn.setOnClickListener(view -> {
            WeightDatabase wdb = new WeightDatabase(UpdateActivity.this);
            wdb.updateWeightData(id,date, weight);
        });

        deleteBtn.setOnClickListener(view -> confirmDelete());



    }

    void getAndSetWeightIntentData(){
        if (getIntent().hasExtra("id") && getIntent().hasExtra("date")&& getIntent().hasExtra("weight")){
            //getting date form intent
            id = getIntent().getStringExtra("id");
            date = getIntent().getStringExtra("date");
            weight = getIntent().getStringExtra("weight");

            //Setting intent data
            updateDate.setText(date);
            updateWeight.setText(weight);

        }
        else{
            Toast.makeText(this, "No data", Toast.LENGTH_SHORT).show();
        }
    }
    void confirmDelete() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Entry");
        builder.setMessage("Are you sure you want to delete:");
        builder.setPositiveButton("Yes", (dialogInterface, i) -> {
            WeightDatabase wdb = new WeightDatabase(UpdateActivity.this);
            wdb.deleteWeightEntry(id);
            finish();
        });
        builder.setNegativeButton("No", (dialogInterface, i) -> {

        });
        builder.create().show();
    }
}
package com.assignment.weighttracker.dailyweight;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.assignment.weighttracker.R;

import java.util.ArrayList;
//adapter to set up list for daily weight
@SuppressWarnings("ALL")
public class WeightAdaptor extends RecyclerView.Adapter<WeightAdaptor.MyViewHolder> {

    private final Context context;
    private final ArrayList weight_Id;
    private final ArrayList weight_Date;
    private final ArrayList weight_weight;
    Activity activity;


    //constructor
    public WeightAdaptor(Activity activity, Context context, ArrayList weight_Id, ArrayList weight_Date, ArrayList weight_weight) {
        this.activity = activity;
        this.context = context;
        this.weight_Id = weight_Id;
        this.weight_Date = weight_Date;
        this.weight_weight = weight_weight;
    }

    @NonNull
    @Override
    public WeightAdaptor.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.data_layout, parent, false);
        return new MyViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull WeightAdaptor.MyViewHolder holder, final int position) {

        holder.tableDate.setText(String.valueOf(weight_Date.get(position)));
        holder.tableWeight.setText(String.valueOf(weight_weight.get(position)));
        holder.mainLayout.setOnClickListener(view -> {
            Intent intent = new Intent(context, UpdateActivity.class);
            intent.putExtra("id",String.valueOf(weight_Id.get(position)));
            intent.putExtra("date",String.valueOf(weight_Date.get(position)));
            intent.putExtra("weight",String.valueOf(weight_weight.get(position)));

            activity.startActivityForResult(intent,1);
        });
    }

    @Override
    public int getItemCount() {
        return weight_Id.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tableDate;
        TextView tableWeight;
        ConstraintLayout mainLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tableDate = itemView.findViewById(R.id.tableDate);
            tableWeight= itemView.findViewById(R.id.tableWeight);
            mainLayout = itemView.findViewById(R.id.mainLayout);
        }
    }
}

package com.assignment.weighttracker.goal;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.assignment.weighttracker.R;
import com.assignment.weighttracker.WeightDatabase;


public class AddGoalActivity extends AppCompatActivity {


    EditText addGoalWeight;
    Button addGoalbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_goal);


        addGoalWeight = findViewById(R.id.addGoalWeight);
        addGoalbtn= findViewById(R.id.addGoalBtn);
        addGoalbtn.setOnClickListener(view -> {
            WeightDatabase wdb = new WeightDatabase(AddGoalActivity.this);
            wdb.addNewGoalEntry(Double.valueOf(addGoalWeight.getText().toString().trim()));
        });
    }
}
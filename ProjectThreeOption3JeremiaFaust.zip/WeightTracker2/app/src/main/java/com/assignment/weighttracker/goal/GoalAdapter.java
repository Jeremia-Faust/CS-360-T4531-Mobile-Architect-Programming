package com.assignment.weighttracker.goal;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.assignment.weighttracker.R;


import java.util.ArrayList;


// adapter for the goal weight
@SuppressWarnings("ALL")
public class GoalAdapter extends RecyclerView.Adapter<GoalAdapter.MyViewHolder> {

    private final Context context;
    private final ArrayList goalWeight_Id;
    private final ArrayList goalWeight_weight;
    Activity activity;



    public GoalAdapter(Activity activity, Context context, ArrayList goalWeight_Id, ArrayList goalWeight_weight) {
        this.activity = activity;
        this.context = context;
        this.goalWeight_Id= goalWeight_Id;
        this.goalWeight_weight = goalWeight_weight;
    }

    @NonNull
    @Override
    public GoalAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.goal_data_layout, parent, false);
        return new MyViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull GoalAdapter.MyViewHolder holder, final int position) {

        holder.goalWeight.setText(String.valueOf(goalWeight_weight.get(position)));
        holder.mainLayout2.setOnClickListener(view -> {
            Intent intent = new Intent(context, UpdateGoalActivity.class);
            intent.putExtra("id",String.valueOf(goalWeight_Id.get(position)));
            intent.putExtra("weight",String.valueOf(goalWeight_weight.get(position)));

            activity.startActivityForResult(intent,1);
        });
    }

    @Override
    public int getItemCount() {
        return goalWeight_Id.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView goalWeight;
        ConstraintLayout mainLayout2;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            goalWeight= itemView.findViewById(R.id.goalWeight);
            mainLayout2 = itemView.findViewById(R.id.mainLayout2);
        }
    }
}

package com.assignment.weighttracker.goal;


import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.assignment.weighttracker.R;
import com.assignment.weighttracker.WeightDatabase;

// This class sets up the update and delete functionality.
// TO DO Update functionality not working.
public class UpdateGoalActivity extends AppCompatActivity {

    EditText addGoalWeight;
    Button addGoalBtn;

    String id, weight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_goal);

        addGoalWeight = findViewById(R.id.addGoalWeight);
        addGoalBtn = findViewById(R.id.addGoalBtn);


        getAndSetWeightIntentData();

        addGoalBtn.setOnClickListener(view -> {
            confirm();
            WeightDatabase wdb = new WeightDatabase(UpdateGoalActivity.this);
            wdb.updateGoalData(id, weight);
        });
    }


    void getAndSetWeightIntentData() {
        if (getIntent().hasExtra("id") && getIntent().hasExtra("weight")) {
            //getting date form intent
            id = getIntent().getStringExtra("id");

            weight = getIntent().getStringExtra("weight");

            //Setting intent data
            addGoalWeight.setText(weight);

        } else {
            Toast.makeText(this, "No data", Toast.LENGTH_SHORT).show();
        }
    }
    //confirm is user want to delete
    void confirm() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Entry");
        builder.setMessage("Are you sure you want to delete:");
        builder.setPositiveButton("Yes", (dialogInterface, i) -> {
            WeightDatabase wdb = new WeightDatabase(UpdateGoalActivity.this);
            wdb.deleteWeightEntry(id);
            finish();
        });
    }
}